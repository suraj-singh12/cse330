/*
given two strings : s1 = CART, s2 = MARCH

3 possible operations:
1. insert
2. remove
3. replace

find minimum operations required to make s1 into s2

*/

