// check if a number is divisible by all prime divisors of another number

#include <iostream>
using namespace std;


// function to compute gcd
int gcd(int a, int b) {
    return (b == 0) ? a : gcd(b, a % b);
}

// function to check if a number is divisible by all prime divisors of another number
bool check(int num1, int num2) {
    if(num2 == 1) return true;

    int gcd1 = gcd(num1, num2);
    if(gcd1 == 1) return false;
    return check(num1, num2 / gcd1);
}
int main() 
{
    int num1, num2;
    cout << "Enter num1 and num2: ";
    cin >> num1 >> num2;
    cout << (check(num1, num2) ? "YES" : "NO") << endl;
}